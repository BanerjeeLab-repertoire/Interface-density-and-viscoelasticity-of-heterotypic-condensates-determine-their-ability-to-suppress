# A1 LCD fibril formation at a condensate interface

Quantitative modeling of A1 LCD (hnRNPA1 low-complexity domain) amyloid
fibril formation catalyzed at the surface of a peptide–ssDNA biomolecular
condensate. 

## Model

| Model | Package | What it is |
|-------|---------|------------|
| **Kinetic** | [`src/kinetic`](src/kinetic) | Compartmental ODE model: dense (`Cc`), dilute (`Cd`) and interfacial (`Cs`) monomer pools + fibril number `N` and mass `M`. Langmuir surface adsorption, surface-catalysed primary/secondary nucleation, dilute-phase elongation. This is the model in the paper/SI. |



## Setup

```bash
pip install -r requirements.txt
```

The packages live under `src/`. Scripts and the notebook add `src/` to
`sys.path` automatically, so no install step is required,  just run them
from the repo.


## Using the models

```python
import sys; sys.path.insert(0, "src")

# Kinetic ODE model
from kinetic import default_params, default_u0, solve, t_frac, IDX
p          = default_params(K_db=2.0, K_s=0.02)
ts, ys     = solve(p, default_u0(), t1=20000)
t5         = t_frac(ts, ys[:, IDX["M"]])

# Phase-field model
from phasefield import PFParams, solve_pf, coarse_grain
ts, grid, c, rho, m, cs = solve_pf(PFParams(), t1=4000)
cg = coarse_grain(ts, grid, c, rho, m, cs)
```

