"""
run.py — Fibril formation model: physics-revised ODE core
==========================================================
Key changes from fibril_model_scipy.ipynb:
  1. Surface adsorption uses proper Langmuir (1 - theta) instead of Hill surf_cap.
     Recovers detailed balance: at equilibrium Cs/Cs_max = K_s*Cd / (1 + K_s*Cd).
  2. g_d gate removed — elongation lag emerges naturally from Cd build-up.
  3. cap_M crowding removed by default (Mmax=inf); monomer depletion self-limits
     growth. Set Mmax to a finite value to re-enable for comparison.
  4. h_s parameter dropped (no longer needed with Langmuir form).

Species:  Cc  condensate | Cd  dilute | Cs  surface | Ct  trapped | N  fibril# | M  mass
"""

import warnings
import itertools
from dataclasses import dataclass, replace, field
from concurrent.futures import ProcessPoolExecutor, as_completed

import numpy as np
from scipy.integrate import solve_ivp

warnings.filterwarnings("ignore", category=UserWarning)


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------

@dataclass
class Params:
    """
    All model parameters.

    Thermodynamic constraints you should respect when varying parameters:
      K_db  = k_in / k_out           (partition coefficient P = Cc/Cd, experimentalist convention)
      K_s   = k_ads_d / k_des_d     (surface equilibrium constant)
      gamma = k_ads_d / k_ads_d0    (kinetic throughput, scales both k_ads & k_des)
    """
    # Geometry
    R:           float = 1.0

    # Bulk <-> dilute partition (thermo)
    k_out:       float = 0.001   # Cc -> Cd
    k_in:        float = 0.002   # Cd -> Cc

    # Dilute <-> surface (kinetics)
    k_ads_d:     float = 0.02    # adsorption rate constant
    k_des_d:     float = 1.0     # desorption rate constant
    Cs_max:      float = 10.0    # maximum surface capacity (Langmuir saturation)

    # Nucleation
    k_nuc:       float = 5e-4    # primary nucleation rate (intrinsic, at reference mobility)
    n_star:      float = 2.0     # critical nucleus size = nucleation order in Cs
    k_2:         float = 1e-5    # secondary nucleation rate (fibril sides on surface recruit Cs)
    m2:          float = 1.0     # secondary nucleation order in M

    # Surface mobility (controls nucleation rate independently of surface loading)
    # mob = (k_des_d / k_des_ref)^beta_mob
    # High residence time (low k_des, tight binding) → low mob → slow nucleation despite high Cs.
    # Set beta_mob=0 to disable (mob≡1); beta_mob=1 gives D_s ∝ k_des (Kramers/Einstein).
    k_des_ref:   float = 1.0     # reference desorption rate (normalises mobility to 1 at default)
    beta_mob:    float = 0.0     # mobility-nucleation coupling exponent (0 = off)

    # Elongation
    k_plus_d:    float = 1e-3    # elongation rate constant

    # Optional crowding cap on M (disabled by default: Mmax=inf → cap_M≡1)
    # Set Mmax to a finite value (e.g. 100) to restore the crowding saturation.
    Mmax:        float = 1e9
    h_M:         float = 4.0

    # Direct dilute-phase nucleation (off by default: k_nuc_d=0)
    # Models solution-phase spontaneous nucleation when Cd > c_sf.
    # c_sf is the implicit saturation threshold: below c_sf surface catalysis
    # is essential; above c_sf this term competes with / dominates surface nucleation.
    k_nuc_d:     float = 0.0     # dilute-phase primary nucleation rate constant

    # Optional bulk trapping (off by default)
    k_trap:      float = 0.0
    k_untrap:    float = 0.0
    R0:          float = 1.0
    alpha_trap:  float = 1.0

    # Numerical
    eps:         float = 1e-12

    @property
    def K_db(self) -> float:
        """Partition coefficient P = Cc/Cd (experimentalist convention: >1 means enriched in condensate)."""
        return self.k_in / self.k_out

    @property
    def K_s(self) -> float:
        """Surface equilibrium constant = k_ads / k_des."""
        return self.k_ads_d / self.k_des_d


def default_params(
    K_db:   float = 2.0,
    k_in0:  float = 0.002,
    k_ads0: float = 0.01,
    k_des0: float = 0.5,
    gamma:  float = 2.0,
    **overrides,
) -> Params:
    """
    Build Params with sensible defaults.

    gamma scales k_ads and k_des together, preserving K_s = k_ads/k_des.
    K_db = P = Cc/Cd is enforced via k_out = k_in / K_db.
    """
    p = Params(
        k_in    = k_in0,
        k_out   = k_in0 / K_db,
        k_ads_d = gamma * k_ads0,
        k_des_d = gamma * k_des0,
    )
    for k, v in overrides.items():
        object.__setattr__(p, k, v)
    return p


# State indices
IDX    = {"Cc": 0, "Cd": 1, "Cs": 2, "Ct": 3, "N": 4, "M": 5}
LABELS = ["Cc", "Cd", "Cs", "Ct", "N", "M"]


def default_u0(Cc0: float = 100.0) -> np.ndarray:
    """Initial condition: all mass in condensate phase."""
    return np.array([Cc0, 0.0, 0.0, 0.0, 0.0, 0.0])


# ---------------------------------------------------------------------------
# ODE right-hand side (physics-revised)
# ---------------------------------------------------------------------------

def fibril_rhs(t, y, p: Params):
    """
    ODE RHS for the revised fibril formation model.

    Physics changes vs. original notebook:
      - Langmuir adsorption: J_ads = k_ads * Cd * (1 - theta)
        where theta = Cs / Cs_max  (proper detailed balance)
      - No g_d gate: elongation = k_plus_d * Cd * N * cap_M
      - cap_M ≡ 1 when Mmax = 1e9 (default); finite Mmax re-enables crowding.
    """
    Cc, Cd, Cs, Ct, N, M = y

    # Clamp negatives
    Cc = max(Cc, 0.0)
    Cd = max(Cd, 0.0)
    Cs = max(Cs, 0.0)
    N  = max(N,  0.0)
    M  = max(M,  0.0)

    AoverV = 3.0 / p.R

    # --- Surface Langmuir occupancy fraction ---
    theta = Cs / (p.Cs_max + p.eps)          # fractional occupancy, in [0, 1]
    theta = min(theta, 1.0)

    # --- Fluxes ---
    # Bulk <-> dilute (first-order, thermodynamically constrained by K_db)
    J_bd = p.k_out * Cc - p.k_in * Cd

    # Surface adsorption/desorption — Langmuir form
    # Equilibrium: Cs/Cs_max = K_s*Cd / (1 + K_s*Cd)  [standard Langmuir isotherm]
    J_ds = AoverV * (p.k_ads_d * Cd * (1.0 - theta) - p.k_des_d * Cs)

    # --- Surface mobility ---
    # mob < 1 when k_des < k_des_ref (tight binding → long residence → slow lateral diffusion)
    # mob > 1 when k_des > k_des_ref (loose binding → short residence → fast lateral diffusion)
    mob = (p.k_des_d / (p.k_des_ref + p.eps)) ** p.beta_mob

    # --- Nucleation (surface processes, both consume Cs) ---
    # Primary: n_star surface monomers spontaneously form a seed
    # Secondary: surface-associated fibril sides template new seeds from Cs
    r_nuc_1 = AoverV * p.k_nuc * mob * Cs ** p.n_star
    r_nuc_2 = AoverV * p.k_2   * mob * Cs * M ** p.m2
    r_nuc   = r_nuc_1 + r_nuc_2

    # --- Direct dilute-phase nucleation (off by default, k_nuc_d=0) ---
    # Represents spontaneous solution nucleation when Cd exceeds c_sf.
    # Consumes Cd instead of Cs; no mobility factor (bulk diffusion, not surface).
    r_nuc_d = p.k_nuc_d * Cd ** p.n_star

    # --- Elongation (no g_d gate; optional crowding cap) ---
    cap_M   = 1.0 / (1.0 + (M / (p.Mmax + p.eps)) ** p.h_M)
    r_elong = p.k_plus_d * Cd * N * cap_M

    # --- Optional bulk trapping ---
    trap_rate   = (p.R / p.R0) ** p.alpha_trap * p.k_trap * Cc
    untrap_rate = p.k_untrap * Ct

    # --- ODEs ---
    dCc = -J_bd - trap_rate + untrap_rate
    dCd =  J_bd - J_ds - r_elong - p.n_star * r_nuc_d   # dilute nuc consumes Cd
    dCs =  J_ds - p.n_star * r_nuc                       # surface nuc consumes Cs
    dCt =  trap_rate - untrap_rate
    dN  =  r_nuc + r_nuc_d
    dM  =  p.n_star * (r_nuc + r_nuc_d) + r_elong

    return [dCc, dCd, dCs, dCt, dN, dM]


# ---------------------------------------------------------------------------
# Solver
# ---------------------------------------------------------------------------

def solve(
    p:      Params,
    u0:     np.ndarray = None,
    t0:     float = 0.0,
    t1:     float = 20000.0,
    n_save: int   = 1000,
    method: str   = "RK45",
    rtol:   float = 1e-8,
    atol:   float = 1e-10,
):
    """
    Integrate the fibril ODE with scipy solve_ivp.

    Returns (ts, ys) where ys has shape (n_save, 6).
    """
    if u0 is None:
        u0 = default_u0()
    ts = np.linspace(t0, t1, n_save)

    sol = solve_ivp(
        fibril_rhs,
        [t0, t1],
        u0,
        args=(p,),
        method=method,
        t_eval=ts,
        rtol=rtol,
        atol=atol,
        dense_output=False,
    )
    if not sol.success:
        warnings.warn(f"Solver did not converge: {sol.message}")

    return sol.t, sol.y.T   # (n_save,), (n_save, 6)


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

def t_frac(ts: np.ndarray, M: np.ndarray, frac: float = 0.05) -> float:
    """
    First time M exceeds frac * M_final.
    Uses final M value as the asymptote (works without knowing Mmax a-priori).
    Returns NaN if threshold never reached.
    """
    thresh = frac * M[-1]
    if thresh <= 0:
        return float("nan")
    idx = np.argmax(M >= thresh)
    return float(ts[idx]) if M[idx] >= thresh else float("nan")


def surface_langmuir_eq(Cd: float, p: Params) -> float:
    """Langmuir equilibrium surface coverage: Cs*/Cs_max = K_s*Cd/(1+K_s*Cd)."""
    K_s = p.K_s
    return p.Cs_max * K_s * Cd / (1.0 + K_s * Cd)


# ---------------------------------------------------------------------------
# Parameter sweeps
# ---------------------------------------------------------------------------

def sweep_1d(
    p_base:     Params,
    field_name: str,
    values,
    u0:         np.ndarray = None,
    t1:         float = 20000.0,
    n_save:     int   = 500,
):
    """
    Sweep one parameter over `values`.
    Returns (values, ts_list, ys_list).
    """
    if u0 is None:
        u0 = default_u0()
    values = list(values)

    results = [solve(replace(p_base, **{field_name: v}), u0, t1=t1, n_save=n_save)
               for v in values]
    return np.array(values), [r[0] for r in results], [r[1] for r in results]


def sweep_2d_t5(
    p_base:    Params,
    field1:    str, vals1,
    field2:    str, vals2,
    u0:        np.ndarray = None,
    t1:        float = 20000.0,
    n_save:    int   = 400,
    frac:      float = 0.05,
    n_workers: int   = 4,
):
    """
    2-D sweep returning t_frac matrix of shape (len(vals1), len(vals2)).
    Parallelised with concurrent.futures.
    """
    if u0 is None:
        u0 = default_u0()
    vals1 = np.asarray(vals1)
    vals2 = np.asarray(vals2)
    n1, n2 = len(vals1), len(vals2)
    grid   = list(itertools.product(range(n1), range(n2)))

    def _run(ij):
        i, j = ij
        p_ij = replace(p_base, **{field1: float(vals1[i]), field2: float(vals2[j])})
        ts_ij, ys_ij = solve(p_ij, u0, t1=t1, n_save=n_save)
        return i, j, t_frac(ts_ij, ys_ij[:, IDX["M"]], frac)

    t5_mat = np.full((n1, n2), np.nan)
    try:
        with ProcessPoolExecutor(max_workers=n_workers) as ex:
            for fut in as_completed({ex.submit(_run, ij): ij for ij in grid}):
                i, j, val = fut.result()
                t5_mat[i, j] = val
    except Exception:
        for ij in grid:
            i, j, val = _run(ij)
            t5_mat[i, j] = val

    return vals1, vals2, t5_mat
