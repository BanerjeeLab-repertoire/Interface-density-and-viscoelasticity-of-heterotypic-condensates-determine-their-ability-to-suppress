"""
viz.py — Visualization utilities for the fibril formation model
===============================================================
All functions return the matplotlib Figure so callers can save or modify them.
Designed to work with run.py outputs.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib import cm

# Match run.py
LABELS = ["Cc", "Cd", "Cs", "Ct", "N", "M"]
IDX    = {"Cc": 0, "Cd": 1, "Cs": 2, "Ct": 3, "N": 4, "M": 5}

plt.rcParams.update({"figure.dpi": 120, "font.size": 10})


# ---------------------------------------------------------------------------
# Single trajectory
# ---------------------------------------------------------------------------

def plot_trajectory(ts, ys, title="Trajectory", figsize=(9, 4), show_Atot=True):
    """
    Plot all six species + optional total mass check vs. time.

    Parameters
    ----------
    ts, ys : arrays returned by run.solve()
    show_Atot : draw dashed total-mass line (should be flat if conserved)
    """
    fig, ax = plt.subplots(figsize=figsize)
    for i, lbl in enumerate(LABELS):
        ax.plot(ts, ys[:, i], lw=2, label=lbl)
    if show_Atot:
        # Atot excludes N (fibril count, not mass); should be flat = mass conservation check
        mass_cols = [IDX[s] for s in ("Cc", "Cd", "Cs", "Ct", "M")]
        ax.plot(ts, ys[:, mass_cols].sum(axis=1), lw=2, ls="--", color="black", label="Atot")
    ax.set_xlabel("time")
    ax.set_ylabel("concentration")
    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.close(fig)
    return fig


def plot_phase_portrait(ts, ys, x_species="Cd", y_species="M",
                        title=None, figsize=(5, 4), color_by_time=True):
    """
    Parametric (phase) plot of two species against each other.
    Color gradient shows time progression.
    """
    x = ys[:, IDX[x_species]]
    y = ys[:, IDX[y_species]]

    fig, ax = plt.subplots(figsize=figsize)
    if color_by_time:
        sc = ax.scatter(x, y, c=ts, cmap="viridis", s=5, linewidths=0)
        plt.colorbar(sc, ax=ax, label="time")
    else:
        ax.plot(x, y, lw=2)
    ax.set_xlabel(x_species)
    ax.set_ylabel(y_species)
    ax.set_title(title or f"{y_species} vs {x_species}")
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    plt.close(fig)
    return fig


# ---------------------------------------------------------------------------
# 1-D sweeps
# ---------------------------------------------------------------------------

def plot_sweep_1d(
    values, ts_list, ys_list,
    species:      str   = "M",
    param_label:  str   = "param",
    title:        str   = "",
    cmap:         str   = "viridis",
    figsize             = (8, 4),
    log_cbar:     bool  = False,
):
    """
    Overlaid M(t) curves for a 1-D parameter sweep.

    Parameters
    ----------
    values, ts_list, ys_list : output of run.sweep_1d()
    log_cbar : use log colorbar (useful for logspace sweeps)
    """
    sid    = IDX[species]
    n      = len(values)
    colors = cm.get_cmap(cmap)(np.linspace(0, 1, n))

    fig, ax = plt.subplots(figsize=figsize)
    for i, v in enumerate(values):
        ax.plot(ts_list[i], ys_list[i][:, sid],
                lw=2, color=colors[i], label=f"{param_label}={v:.3g}")

    ax.set_xlabel("time")
    ax.set_ylabel(species)
    ax.set_title(title or f"Sweep of {param_label}")
    ax.legend(fontsize=7, loc="upper left", ncol=2, framealpha=0.4)
    ax.spines[["top", "right"]].set_visible(False)

    norm = (mcolors.LogNorm(float(values[0]), float(values[-1])) if log_cbar
            else mcolors.Normalize(float(values[0]), float(values[-1])))
    sm = cm.ScalarMappable(cmap=cmap, norm=norm)
    sm.set_array([])
    plt.colorbar(sm, ax=ax, label=param_label, pad=0.02)
    plt.tight_layout()
    plt.close(fig)
    return fig


def plot_multi_sweep(
    sweep_configs,
    p_base, sweep_fn,
    species: str  = "M",
    t1:      float = 20000.0,
    n_save:  int   = 500,
    figsize        = (22, 4),
):
    """
    Multi-panel sweep figure.

    Parameters
    ----------
    sweep_configs : list of (field_name, values_array, label_str)
    sweep_fn      : run.sweep_1d
    """
    n_panels = len(sweep_configs)
    fig, axes = plt.subplots(1, n_panels, figsize=figsize)
    if n_panels == 1:
        axes = [axes]

    for ax, (field, vals, lbl) in zip(axes, sweep_configs):
        vs, ts_b, ys_b = sweep_fn(p_base, field, vals, t1=t1, n_save=n_save)
        n = len(vs)
        colors = cm.get_cmap("viridis")(np.linspace(0, 1, n))
        for i in range(n):
            ax.plot(ts_b[i], ys_b[i][:, IDX[species]], lw=1.8, color=colors[i])
        ax.set_title(f"Sweep of {lbl}", fontsize=10)
        ax.set_xlabel("time")
        ax.set_ylabel(f"{species}(t)")
        ax.spines[["top", "right"]].set_visible(False)
        sm = cm.ScalarMappable(
            cmap="viridis",
            norm=mcolors.Normalize(float(vs[0]), float(vs[-1]))
        )
        sm.set_array([])
        fig.colorbar(sm, ax=ax, label=lbl, pad=0.02)

    plt.tight_layout()
    plt.close(fig)
    return fig


# ---------------------------------------------------------------------------
# 2-D heatmap (t_frac)
# ---------------------------------------------------------------------------

def plot_heatmap_t5(
    vals1, vals2, t5_mat,
    xlabel:        str  = "param1",
    ylabel:        str  = "param2",
    title:         str  = r"$t_{5\%}$",
    log_axes:      bool = False,
    overlay_ratios: dict = None,   # {ratio: label_str} draws constant-K lines
    figsize             = (6, 5),
):
    """
    Heatmap of t_frac over a 2-D parameter grid.

    Parameters
    ----------
    vals1, vals2, t5_mat : output of run.sweep_2d_t5()
    overlay_ratios : e.g. {0.5: "0.5", 1.0: "1.0"} draws ratio*vals1 lines
    """
    fig, ax = plt.subplots(figsize=figsize)
    x = np.array(vals1)
    y = np.array(vals2)
    Z = np.array(t5_mat).T

    x_plot = np.log10(x) if log_axes else x
    y_plot = np.log10(y) if log_axes else y

    im = ax.pcolormesh(x_plot, y_plot, Z, cmap="viridis_r", shading="auto")
    plt.colorbar(im, ax=ax, label=r"$t_{5\%}$")

    if overlay_ratios:
        for ratio, lbl in overlay_ratios.items():
            y_line = ratio * x
            mask   = (y_line >= y.min()) & (y_line <= y.max())
            xp = np.log10(x[mask]) if log_axes else x[mask]
            yp = np.log10(y_line[mask]) if log_axes else y_line[mask]
            ax.plot(xp, yp, lw=1.5, ls="--", label=f"ratio={lbl}")
        ax.legend(fontsize=8)

    pref = "log\u2081\u2080 " if log_axes else ""
    ax.set_xlabel(pref + xlabel)
    ax.set_ylabel(pref + ylabel)
    ax.set_title(title)
    plt.tight_layout()
    plt.close(fig)
    return fig


# ---------------------------------------------------------------------------
# γ-sweep diagnostic (same partition, varying surface throughput)
# ---------------------------------------------------------------------------

def plot_gamma_sweep(gamma_vals, ts_g, ys_g, p_fixed,
                     k_des0: float = 0.5, Kdb_fixed: float = 0.2,
                     figsize=(12, 9)):
    """
    4-panel figure for the γ-sweep experiment:
      M(t) | J_s→d | Cd/Cb partition | t5% vs γ.

    Parameters
    ----------
    gamma_vals : 1-D array of γ values
    ts_g, ys_g : list of ts/ys arrays, one per γ value
    p_fixed    : base Params (used for R)
    k_des0     : baseline k_des before γ scaling
    Kdb_fixed  : expected asymptote for Cd/Cb
    """
    from run import IDX, t_frac

    n_g    = len(gamma_vals)
    colors = cm.get_cmap("viridis")(np.linspace(0, 1, n_g))
    AoverV = 3.0 / p_fixed.R

    # Compute diagnostics
    M_all    = [ys[:, IDX["M"]]  for ys in ys_g]
    Cd_all   = [ys[:, IDX["Cd"]] for ys in ys_g]
    Cc_all   = [ys[:, IDX["Cc"]] for ys in ys_g]
    Cs_all   = [ys[:, IDX["Cs"]] for ys in ys_g]
    J_sd_all = [AoverV * float(gamma_vals[i]) * k_des0 * Cs_all[i]
                for i in range(n_g)]
    CdCc_all = [Cd_all[i] / (Cc_all[i] + 1e-12) for i in range(n_g)]
    t5_vals  = [t_frac(ts_g[i], M_all[i]) for i in range(n_g)]

    fig, axes = plt.subplots(2, 2, figsize=figsize)

    # Panel 1 — M(t)
    ax = axes[0, 0]
    for i in range(n_g):
        ax.plot(ts_g[i], M_all[i], lw=2, color=colors[i])
    ax.set_title(r"Fibril mass $M(t)$ — fixed $K_{db}$, varying $\gamma$")
    ax.set_xlabel("time"); ax.set_ylabel("M(t)")
    ax.spines[["top", "right"]].set_visible(False)
    sm = cm.ScalarMappable(cmap="viridis",
                           norm=mcolors.LogNorm(float(gamma_vals[0]),
                                                float(gamma_vals[-1])))
    sm.set_array([])
    plt.colorbar(sm, ax=ax, label=r"$\gamma$")

    # Panel 2 — surface efflux
    ax = axes[0, 1]
    for i in range(n_g):
        ax.plot(ts_g[i], J_sd_all[i], lw=2, color=colors[i])
    ax.set_title(r"Surface efflux $J_{s\to d}$")
    ax.set_xlabel("time"); ax.set_ylabel(r"$J_{s\to d}$")
    ax.spines[["top", "right"]].set_visible(False)
    plt.colorbar(sm, ax=ax, label=r"$\gamma$")

    # Panel 3 — partition diagnostic
    ax = axes[1, 0]
    for i in range(n_g):
        ax.plot(ts_g[i], CdCc_all[i], lw=2, color=colors[i])
    ax.axhline(1.0/Kdb_fixed, ls="--", color="red", lw=1.5,
               label=f"$1/K_{{db}}={1.0/Kdb_fixed:.2f}$")
    ax.set_title(r"Partition diagnostic $C_d/C_c$ (should converge to $1/K_{db}$)")
    ax.set_xlabel("time"); ax.set_ylabel(r"$C_d/C_c$")
    ax.legend(fontsize=9)
    ax.spines[["top", "right"]].set_visible(False)

    # Panel 4 — t5% vs γ
    ax = axes[1, 1]
    gv = np.array([float(g) for g in gamma_vals])
    ax.scatter(gv, t5_vals, s=70, zorder=3,
               c=np.log10(gv), cmap="viridis")
    ax.plot(gv, t5_vals, lw=1.5, color="gray", zorder=2)
    ax.set_xscale("log")
    ax.set_title(r"Lag time $t_{5\%}$ vs $\gamma$")
    ax.set_xlabel(r"$\gamma$"); ax.set_ylabel(r"$t_{5\%}$")
    ax.spines[["top", "right"]].set_visible(False)

    plt.suptitle(
        rf"$\gamma$-sweep: fixed $K_{{db}}={Kdb_fixed}$, varying surface kinetics",
        fontsize=13, y=1.01
    )
    plt.tight_layout()
    plt.close(fig)
    return fig


def plot_two_phenotypes(ts_fast, ys_fast, ts_slow, ys_slow,
                        label_fast="RGPGG-like", label_slow="RGRGG-like",
                        figsize=(12, 8)):
    """
    4-panel comparison: M(t), fluxes, throughput vs occupancy, partition.
    """
    from run import IDX

    def _fluxes(ts, ys, p):
        Cc = ys[:, IDX["Cc"]]; Cd = ys[:, IDX["Cd"]]; Cs = ys[:, IDX["Cs"]]
        AoverV = 3.0 / p.R
        J_bd = p.k_out * Cc - p.k_in * Cd
        J_sd = AoverV * (p.k_des_d * Cs - p.k_ads_d * Cd * (1 - Cs / (p.Cs_max + p.eps)))
        return J_bd, J_sd, Cd / (Cc + 1e-12)

    sty = {
        "fast": {"color": "steelblue",  "lw": 2.5, "label": label_fast},
        "slow": {"color": "darkorange", "lw": 2.5, "label": label_slow},
    }

    fig, axes = plt.subplots(2, 2, figsize=figsize)

    ax = axes[0, 0]
    ax.plot(ts_slow, ys_slow[:, IDX["M"]], **sty["slow"])
    ax.plot(ts_fast, ys_fast[:, IDX["M"]], **sty["fast"])
    ax.set_title("Fibril growth at fixed partition")
    ax.set_xlabel("time"); ax.set_ylabel("M(t)")
    ax.legend(); ax.spines[["top", "right"]].set_visible(False)

    ax = axes[0, 1]
    ax.plot(ts_slow, ys_slow[:, IDX["Cs"]], **sty["slow"])
    ax.plot(ts_fast, ys_fast[:, IDX["Cs"]], **sty["fast"])
    ax.set_title(r"Surface occupancy $C_s(t)$")
    ax.set_xlabel("time"); ax.set_ylabel(r"$C_s$")
    ax.legend(); ax.spines[["top", "right"]].set_visible(False)

    ax = axes[1, 0]
    Cs_s = ys_slow[:, IDX["Cs"]]
    Cs_f = ys_fast[:, IDX["Cs"]]
    ax.plot(ts_slow, Cs_s / Cs_s.max(), **sty["slow"])
    ax.plot(ts_fast, Cs_f / Cs_f.max(), **sty["fast"])
    ax.set_title(r"Normalised $C_s$ (sticky $\neq$ high flux)")
    ax.set_xlabel("time"); ax.set_ylabel(r"$C_s / C_s^{max}$")
    ax.legend(); ax.spines[["top", "right"]].set_visible(False)

    ax = axes[1, 1]
    CdCc_s = ys_slow[:, IDX["Cd"]] / (ys_slow[:, IDX["Cc"]] + 1e-12)
    CdCc_f = ys_fast[:, IDX["Cd"]] / (ys_fast[:, IDX["Cc"]] + 1e-12)
    ax.plot(ts_slow, CdCc_s, **sty["slow"])
    ax.plot(ts_fast, CdCc_f, **sty["fast"])
    ax.set_title(r"Partition diagnostic $C_d/C_c$")
    ax.set_xlabel("time"); ax.set_ylabel(r"$C_d/C_c$")
    ax.legend(); ax.spines[["top", "right"]].set_visible(False)

    plt.suptitle("Two-phenotype comparison at fixed partition",
                 fontsize=13, y=1.01)
    plt.tight_layout()
    plt.close(fig)
    return fig
